# VocalSet preparation

## Source
- Release: Wilkins, Seetharaman, Wahl, Pardo, ISMIR 2018
- Zenodo record: https://zenodo.org/records/1442513
- DOI: 10.5281/zenodo.1442513
- License: CC BY 4.0
- Access: open download, no application required

## Composition
- 20 professional singers (11 female, 9 male)
- 17 singing techniques across 5 vowels
- Performance contexts: scales, arpeggios, long tones, excerpts
- About 3,560 WAV files totalling 10.1 hours
- Sampling rate: 44,100 Hz

## Expected layout after download

```
data/raw/vocalset/
└── FULL/
    ├── female1/
    │   ├── straight/
    │   │   ├── arpeggios/
    │   │   │   └── a_arpeggios_straight.wav
    │   │   ├── scales/
    │   │   └── long_tones/
    │   ├── vibrato/
    │   ├── belt/
    │   └── ...                       # 17 technique directories
    ├── female2/
    ├── ...
    └── male11/
```

VocalSet 1.2 ships three parallel organisations (by singer / by
technique / by vowel). The loader in `cfdsing/data/datasets.py` reads
the `FULL/<singer>/<technique>/*.wav` arrangement; you can symlink the
other arrangements if you prefer them.

## Technique labels
The 17 technique directory names are taken verbatim from the corpus and
used as zero-shot technique labels: `belt`, `breathy`, `inhaled`,
`lip_trill`, `spoken`, `straight`, `trill`, `trillo`, `vibrato`,
`vocal_fry`, plus the seven less common techniques (`messa`,
`forte`, `piano`, `pp`, `slow_vibrato`, `fast_vibrato`,
`crescendo`).

## Role in CFD-Sing
VocalSet is used exclusively for zero-shot evaluation of the technique
disentanglement (Section 4.7 of the paper). No phoneme alignment or
note score is required, because the audio descriptors consumed by the
technique branch (Eq. 5) are computed directly from the waveform.
