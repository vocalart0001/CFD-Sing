# PopBuTFy preparation

## Source
- Release: NeuralSVB (Liu et al., ACL 2022)
- Repository: https://github.com/MoonInTheRiver/NeuralSVB
- License: CC BY-NC-SA 4.0 (non-commercial)
- Application: submit the signed `apply_form.md` from `resources/` of the
  official repository, using an institutional email address.

## Composition
- 99 Mandarin Chinese pop songs (12 singers) and 443 English pop songs
  (22 singers), totalling roughly 50 hours of audio
- Each song carries a parallel amateur / professional recording from the
  same singer for the singing voice beautifying task
- Sampling rate: 22,050 Hz, 16-bit PCM

## Expected layout after download

```
data/raw/popbutfy/
├── train.tsv                            # TSV index with columns:
│                                        #   wav, textgrid, singer, language, level
├── val.tsv
├── test.tsv
├── wavs/
│   ├── <singer>_<song>_<seg>_amateur.wav
│   └── <singer>_<song>_<seg>_professional.wav
├── textgrids/                           # MFA-aligned phoneme tier
│   ├── <singer>_<song>_<seg>_amateur.TextGrid
│   └── <singer>_<song>_<seg>_professional.TextGrid
└── lyrics/
    └── <singer>_<song>_<seg>.txt
```

## TSV index format
Each `<split>.tsv` file is a tab-separated table whose columns match
the names expected by the `PopBuTFy` loader in
`cfdsing/data/datasets.py`:

| column   | description                                    |
|----------|------------------------------------------------|
| wav      | Path relative to `data/raw/popbutfy/`          |
| textgrid | Path relative to `data/raw/popbutfy/`          |
| singer   | Singer identifier                              |
| language | `zh` or `en`                                   |
| level    | `amateur` or `professional`                    |

## Forced alignment
Run MFA on every pair of (audio file, lyric text file) to populate the
`textgrids/` directory. The English subset uses the
`english_us_arpa` acoustic model + dictionary; the Mandarin subset uses
`mandarin_mfa`. See `../format_specs/textgrid_format.md` for the tier
structure expected by the data loader.

## Role in CFD-Sing
PopBuTFy is the main training corpus. The parallel amateur / professional
pairs supply the supervision signal used to learn the counterfactual
mapping (Eq. 9). All 32 singers are used during training; 274 Chinese
and 617 English segments are reserved for validation and test as defined
by `val.tsv` and `test.tsv`.
