# NHSS preparation

## Source
- Release: HLT Lab, National University of Singapore
  (Sharma, Gao, Vijayan, Tian, Li, *Speech Communication*, 2021)
- Homepage: https://hltnus.github.io/NHSSDatabase/
- Access: open download after EULA acceptance

## Composition
- 100 English pop songs sung and spoken by 10 professional singers
  (5 female, 5 male)
- 20 unique song titles; each singer covers 10 songs
- 4.75 hours of sung audio + 2.25 hours of spoken counterpart =
  7 hours total
- Sampling rate: 16,000 Hz
- Annotations: utterance- and word-level boundaries

## Expected layout after download

```
data/raw/nhss/
├── M01/
│   ├── sing/
│   │   ├── <song_id>/
│   │   │   ├── <song_id>.wav
│   │   │   ├── <song_id>.TextGrid       # word + utterance tiers
│   │   │   └── <song_id>.txt            # lyrics
│   │   └── ...
│   └── read/
│       └── <song_id>/
│           ├── <song_id>.wav
│           └── <song_id>.TextGrid
├── M02/
├── ...
└── F05/                                  # 10 singers total: M01-M05 + F01-F05
```

The data loader in `cfdsing/data/datasets.py` walks the singer
directories and reads only the `sing/` branch. The `read/` branch
(spoken counterpart) is left untouched in this project.

## Splits
NHSS does not ship a canonical split. The loader uses 8 singers for
zero-shot evaluation and reserves 2 singers (1 male, 1 female) as a
held-out subset, following the cross-singer convention in the literature.

## Role in CFD-Sing
NHSS provides the English zero-shot cross-dataset evaluation reported in
Section 4.7 of the paper. Audio + word-level boundaries are sufficient
for running the phoneme condition (Eq. 3) and the attribution metric
(Algorithm 2); note pitch is derived from the f0 trajectory of the
audio when no MIDI is available.
