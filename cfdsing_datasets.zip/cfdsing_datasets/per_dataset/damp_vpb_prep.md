# DAMP-VPB preparation

## Source
- Release: Smule, Inc.
- Zenodo record: https://zenodo.org/records/2616690
- DOI: 10.5281/zenodo.2616690
- Access: by application — researchers must accept Smule's Research Data
  License Agreement (non-redistribution, non-commercial).

## Composition
- 24,874 solo singing performances from 5,429 singers across 14
  backing tracks (a balanced design)
- Mobile-app karaoke recordings collected through the Smule platform
- Singer pool spans many countries and accents
- Audio is delivered as M4A (mobile codec); resample to a consistent
  rate before training.

## Expected layout after download

```
data/raw/damp_vpb/
├── metadata.csv                     # See columns below
├── audio/
│   └── <recording_id>.m4a
└── splits/                          # Recommended train/val/test partitions
    ├── train.csv
    ├── val.csv
    └── test.csv
```

## metadata.csv columns
The DAMP-VPB loader in `cfdsing/data/datasets.py` consumes the
following columns:

| column      | description                                    |
|-------------|------------------------------------------------|
| filename    | M4A path relative to `audio/`                  |
| singer_id   | Stable singer identifier                       |
| song_id     | Backing-track identifier                       |
| gender      | `M` or `F`                                     |
| region      | Two-letter region code (country / locale)      |
| love_count  | Social signal from the original app            |

## Audio preprocessing
Resample every M4A to 22,050 Hz mono WAV before use:

```bash
for f in data/raw/damp_vpb/audio/*.m4a; do
    out="data/raw/damp_vpb/audio_22k/$(basename "$f" .m4a).wav"
    ffmpeg -i "$f" -ac 1 -ar 22050 -sample_fmt s16 -y "$out"
done
```

Then point `metadata.csv` rows at the new WAV files (or symlink the
directory).

## Role in CFD-Sing
DAMP-VPB is used exclusively for the zero-shot diversity evaluation in
Section 4.7. Only audio + minimal metadata are required; no
lyric-driven correction is performed on this dataset. The chosen subset
for the paper covers 1,200+ singers and 80+ hours.
