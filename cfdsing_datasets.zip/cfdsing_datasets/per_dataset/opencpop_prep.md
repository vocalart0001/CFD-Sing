# OpenCpop preparation

## Source
- Release: WeNet open-source community (Wang et al., INTERSPEECH 2022)
- Homepage: https://wenet-e2e.github.io/opencpop/
- Repository: https://github.com/wenet-e2e/opencpop
- Application: through the Download entry on the homepage; free for
  research use.

## Composition
- 100 Mandarin pop songs recorded by a single professional female singer
- 3,756 utterance-level segments, totalling about 5.2 hours
- Sampling rate: 44,100 Hz, 16-bit PCM
- Annotations: phoneme + syllable + note boundaries, plus MIDI scores

## Expected layout after download

```
data/raw/opencpop/
├── transcriptions.txt              # Pipe-separated index
├── wavs/
│   └── <utt_id>.wav
├── textgrids/                      # Phoneme + syllable + note tiers
│   └── <utt_id>.TextGrid
├── midis/                          # Per-utterance MIDI score
│   └── <utt_id>.mid
└── splits/
    ├── train.txt
    ├── valid.txt
    └── test.txt
```

## transcriptions.txt format
One utterance per line, pipe-separated. Six fields:

```
<utt_id>|<characters>|<pinyin>|<note_names>|<note_durations>|<phoneme_durations>
```

The OpenCpop loader in `cfdsing/data/datasets.py` reads the `<utt_id>` of
each line and resolves the audio / TextGrid / MIDI paths above.

## Splits
The official split reserves 5 randomly chosen songs for the test set.
`train.txt`, `valid.txt`, `test.txt` list the corresponding `<utt_id>`
values one per line.

## Role in CFD-Sing
OpenCpop is the Mandarin component of the main training corpus. Because
it is the only one of the five datasets that ships with MIDI scores and
note-boundary annotations, it grounds the melody condition (Eq. 4) and
is also the source of the f0 templates used at correction time.
