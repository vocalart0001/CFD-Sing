# TextGrid format specification

The CFD-Sing pipeline consumes MFA-style TextGrid files for phoneme
alignment. This document defines the tier layout expected by the
`load_textgrid` helper in `cfdsing/data/datasets.py`.

## File format
- Plain text Praat TextGrid (UTF-8 encoded)
- One TextGrid per audio segment, sharing the audio file's stem name

## Required tier

| tier name | type        | description                                  |
|-----------|-------------|----------------------------------------------|
| phones    | IntervalTier| Phoneme boundaries (one interval per phoneme)|

## Optional tiers

| tier name | type        | description                                  |
|-----------|-------------|----------------------------------------------|
| words     | IntervalTier| Word-level boundaries (used by NHSS)         |
| syllables | IntervalTier| Syllable-level boundaries (used by OpenCpop) |
| notes     | IntervalTier| Note-level boundaries (used by OpenCpop)     |

The loader currently parses only the `phones` tier. Other tiers are kept
in the file for downstream tools but are ignored.

## Phoneme labels
Each interval text must use a label from `phoneme_vocab.txt`:

- English ARPABET symbols (`AA`, `AE`, `B`, `CH`, ...)
- Mandarin Pinyin initials and finals (`b`, `p`, `m`, `ai`, `iang`, ...)
- Silence: `<sil>`
- Out-of-vocabulary: `<unk>`

Empty interval text is treated as silence.

## Time units
Praat default: seconds, double precision. The loader converts
seconds to frame indices using the configured hop length and sampling
rate (default 256 samples at 22,050 Hz → ≈ 11.6 ms per frame).

## Producing TextGrids with MFA

```bash
# Train an MFA acoustic model on the dataset (one-time)
mfa train data/raw/<dataset>/lyrics_corpus \
         english_us_arpa \
         data/aligners/<dataset>.zip

# Align each audio file with its lyric transcript
mfa align data/raw/<dataset>/lyrics_corpus \
          english_us_arpa \
          data/aligners/<dataset>.zip \
          data/raw/<dataset>/textgrids/
```

Substitute `mandarin_mfa` for the Mandarin component of PopBuTFy and
for OpenCpop.
