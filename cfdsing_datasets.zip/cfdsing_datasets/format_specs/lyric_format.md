# Lyric file format specification

Lyric files supply the orthographic transcript that MFA uses to derive
phoneme alignments. They are read by the MFA preparation step and by
the inference entry point in `inference/correct.py`.

## File format
- Plain UTF-8 text, `.txt` extension
- One file per audio segment, sharing the audio's stem name
- Content: the spoken / sung text in the original orthography
- Casing: as written (MFA's English dictionary is case-insensitive)
- Line breaks: one phrase per line is recommended but not required

## Language conventions

### English (PopBuTFy English subset, NHSS)
- Standard orthography
- Numbers spelled out (`one`, not `1`)
- Contractions kept (`don't`, `you'll`)
- Punctuation tolerated but ignored by MFA

### Mandarin (PopBuTFy Mandarin subset, OpenCpop)
- Simplified Chinese characters
- One character per syllable (Pinyin tonal marks are added by the
  aligner using its built-in dictionary)
- Filler syllables (`啊`, `嗯`) are kept

### VocalSet, DAMP-VPB
- No lyric files are required for these corpora; they are not used in
  the lyric-driven part of the pipeline.

## OpenCpop convention
The OpenCpop release ships orthography inside `transcriptions.txt`
rather than per-file `.txt`. The OpenCpop loader reads the
`<utt_id>|<characters>|...` field and reconstructs the per-utterance
transcript on the fly, so no separate `.txt` files are required for
this dataset.

## Naming convention
For every audio file
```
<root>/wavs/<utt_id>.wav
```
the matching lyric file lives at
```
<root>/lyrics/<utt_id>.txt
```
and the MFA-aligned grid at
```
<root>/textgrids/<utt_id>.TextGrid
```

## Unknown tokens
Words outside the MFA dictionary are mapped to `<unk>` in the alignment.
A small number of `<unk>` tokens is acceptable; if a segment has more
than 30 % unknowns, drop the segment from training.
