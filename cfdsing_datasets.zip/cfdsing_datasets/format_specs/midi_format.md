# MIDI score format specification

MIDI scores feed the melody condition (Eq. 4) of the CFD-Sing model.
This document defines the format expected by the `_load_midi_notes`
helper in `cfdsing/data/datasets.py`.

## File format
- Standard MIDI File (SMF), format 0 or 1
- One MIDI file per utterance, sharing the audio's stem name
- One monophonic melody track is sufficient; polyphonic tracks are
  reduced to the top note per simultaneous group

## Required messages

| message      | role                                            |
|--------------|-------------------------------------------------|
| `note_on`    | Start of a note. Velocity > 0.                  |
| `note_off`   | End of a note. Also matches `note_on velocity 0`.|
| `set_tempo`  | Microseconds per beat. At least one is required.|

Time signature, key signature, and instrument programme messages are
tolerated but ignored.

## Pitch encoding
Note numbers follow the General MIDI convention:
- A4 = 69 = 440.000 Hz
- Hz conversion: `f = 440 * 2 ** ((note - 69) / 12)`

The `_load_midi_notes` helper returns floating-point Hertz, not MIDI
note numbers.

## Duration encoding
Note duration is derived from the tick delta between `note_on` and
`note_off`, scaled by the active tempo. The helper accumulates
real-world time in seconds across nested tempo changes.

## Per-dataset availability

| dataset  | MIDI shipped | fallback                                    |
|----------|--------------|---------------------------------------------|
| OpenCpop | ✓            | —                                           |
| PopBuTFy | partial      | f0 trajectory + phoneme boundaries          |
| VocalSet | —            | not needed (technique branch only)          |
| NHSS     | —            | f0 trajectory + word boundaries             |
| DAMP-VPB | —            | not needed (zero-shot diversity evaluation) |

For datasets without MIDI, the loader falls back to `_f0_to_notes`,
which groups consecutive voiced f0 frames into pseudo-notes and uses
phoneme boundaries to align them onto the phoneme timeline.

## Per-utterance file naming
For every audio file
```
<root>/wavs/<utt_id>.wav
```
the matching MIDI score (when present) lives at
```
<root>/midis/<utt_id>.mid
```
