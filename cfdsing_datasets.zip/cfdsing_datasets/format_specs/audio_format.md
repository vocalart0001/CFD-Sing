# Audio format specification

The CFD-Sing pipeline reads mono singing waveforms and re-uses them at a
common sampling rate. The native formats of the five public datasets
differ; this document defines the canonical target format used after
preprocessing.

## Canonical format

| field        | value                                          |
|--------------|------------------------------------------------|
| container    | WAV (RIFF), PCM                                |
| channels     | 1 (mono)                                       |
| sampling rate| 22,050 Hz                                      |
| bit depth    | 16-bit signed integer (`s16le`)                |
| amplitude    | peak-normalised to ≤ 1.0 in floating point     |

## Native rates by dataset

| dataset  | native rate | bit depth | format |
|----------|-------------|-----------|--------|
| PopBuTFy | 22,050 Hz   | 16-bit    | WAV    |
| OpenCpop | 44,100 Hz   | 16-bit    | WAV    |
| VocalSet | 44,100 Hz   | 16-bit    | WAV    |
| NHSS     | 16,000 Hz   | 16-bit    | WAV    |
| DAMP-VPB | varies      | varies    | M4A    |

## Resampling

The `load_wav` helper in `cfdsing/data/datasets.py` resamples on-the-fly
to the rate set in `configs/cfd_sing.yaml` (`mel.sample_rate`, default
22,050 Hz). For DAMP-VPB the M4A files should be converted to WAV
ahead of time (see `per_dataset/damp_vpb_prep.md`).

## Channel handling

Stereo files (if any) are averaged to mono on load. Multi-track
NHSS recordings keep the singing-only channel as released by the HLT
lab.

## Loudness normalisation

The loader peak-normalises each clip so that the maximum absolute
amplitude is at most 1.0. No LUFS normalisation is applied, which keeps
the technique branch sensitive to natural loudness variation.
